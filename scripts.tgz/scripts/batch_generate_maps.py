#!/var/www/cap_winds_app/venv/bin/python3
"""
Batch Map Generation Script - CORRECTED FOR WindAnalysisService
Generates aviation wind maps for all configured regions

Usage:
  ./batch_generate_maps.py

Cron:
  5 * * * * /var/www/cap_winds_app/scripts/batch_generate_maps.py >> /var/log/batch_maps.log 2>&1
"""

import sys
import os
import logging
from datetime import datetime

# Add app directory to path
sys.path.insert(0, '/var/www/cap_winds_app')

try:
    import states_service
except ImportError as e:
    print(f"Error importing states_service: {e}")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
log = logging.getLogger(__name__)

# Output directory
#OUTPUT_DIR = "/var/www/html/cap_winds"
OUTPUT_DIR = "/var/www/cap_winds_app/static/batch_maps"

# Region configurations (code, name, output_filename)
REGIONS = [
    ("conus", "Continental United States", "conus.png"),
    ("NCR", "North Central Region", "ncr.png"),
    ("GLR", "Great Lakes Region", "glr.png"),
    ("NER", "Northeast Region", "ner.png"),
    ("PCR", "Pacific Region", "pcr.png"),
    ("PCR-WEST", "PCR-West Coast", "pcr-west.png"),
    ("PCR-AK", "PCR-Alaska", "pcr-ak.png"),
    ("PCR-HI", "PCR-Hawaii", "pcr-hi.png"),
    ("PCR-GUAM", "PCR-Guam", "pcr-guam.png"),
    ("RMR", "Rocky Mountain Region", "rmr.png"),
    ("SER", "Southeast Region", "ser.png"),
    ("SER-CARIB", "SER-Caribbean", "ser-carib.png"),
    ("SWR", "Southwest Region", "swr.png"),
]


def generate_map(service, location_code, display_name, output_filename):
    """
    Generate map for a single region
    Returns True on success, False on failure
    """
    try:
        log.info(f"Starting: {display_name} ({location_code})")
        
        # Determine location_type based on code
        if location_code.lower() == 'conus':
            location_type = 'conus'
            region_code = ''
        else:
            location_type = 'region'
            region_code = location_code
        
        # Generate the analysis using correct parameters
        result = service.generate_analysis(
            location_type=location_type,
            location_code=region_code
        )
        
        if result and isinstance(result, list) and len(result) > 0:
            # Result is List[Dict], get the generated map
            map_info = result[0]
            generated_map = map_info.get('map_path') or map_info.get('url')
            
            if generated_map and os.path.exists(generated_map):
                # Rename to static filename (overwrite previous)
                static_path = os.path.join(OUTPUT_DIR, output_filename)
                if generated_map != static_path:
                    os.rename(generated_map, static_path)
                
                log.info(f"✓ Success: {display_name} → {output_filename}")
                return True
            else:
                log.error(f"✗ Failed: {display_name} - Map file not found")
                return False
        else:
            log.error(f"✗ Failed: {display_name} - No maps generated")
            return False
            
    except Exception as e:
        log.error(f"✗ Failed: {display_name} - {str(e)}")
        return False


def cleanup_old_timestamped_maps():
    """Clean up old timestamped maps from previous versions"""
    if not os.path.exists(OUTPUT_DIR):
        return
    
    try:
        import re
        timestamped_pattern = re.compile(r'.*_\d{6}Z[A-Z]{3}\d{2}\.png$')
        
        removed_count = 0
        for filename in os.listdir(OUTPUT_DIR):
            if timestamped_pattern.match(filename):
                filepath = os.path.join(OUTPUT_DIR, filename)
                try:
                    os.remove(filepath)
                    removed_count += 1
                except Exception as e:
                    log.debug(f"Could not remove {filename}: {e}")
        
        if removed_count > 0:
            log.info(f"Cleaned up {removed_count} old timestamped maps")
            
    except Exception as e:
        log.debug(f"Cleanup error: {e}")


def main():
    """Main execution"""
    log.info("=" * 70)
    log.info(f"Batch Map Generation Started: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    log.info("=" * 70)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Initialize service
    try:
        service = states_service.WindAnalysisService()
        log.info("✓ Initialized WindAnalysisService")
    except Exception as e:
        log.error(f"Failed to initialize WindAnalysisService: {e}")
        sys.exit(1)
    
    # Track results
    succeeded = []
    failed = []
    
    # Generate each region map
    for code, display_name, output_filename in REGIONS:
        success = generate_map(service, code, display_name, output_filename)
        
        if success:
            succeeded.append(display_name)
        else:
            failed.append(display_name)
    
    # Clean up old timestamped maps
    cleanup_old_timestamped_maps()
    
    # Summary
    log.info("=" * 70)
    log.info(f"Batch Generation Complete: {len(succeeded)} succeeded, {len(failed)} failed")
    if failed:
        log.info(f"Failed regions: {', '.join(failed)}")
    log.info("=" * 70)
    
    # Exit with appropriate code
    sys.exit(0 if len(failed) == 0 else 1)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        log.info("Interrupted by user")
        sys.exit(1)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
