#!/usr/bin/env python3
"""
Repopulate observations.airports table with ONLY airports having paved runways >= 2500 ft
This ensures the database matches the filtering criteria from the static map version.
"""

import sys
import pandas as pd
import psycopg2
from psycopg2 import sql

# Database configuration - EDIT THESE
DB_CONFIG = {
    'host': 'localhost',
    'database': 'avwx_data',
    'user': 'avwx_user',
    'password': 'change_me_in_production'
}

# Data sources
AIRPORT_URL = 'https://davidmegginson.github.io/ourairports-data/airports.csv'
RUNWAY_URL = 'https://davidmegginson.github.io/ourairports-data/runways.csv'

# Filtering criteria (must match static map version)
PAVED_SURFACES = ['ASP', 'ASPH', 'CON', 'CONC', 'concrete', 'asphalt']
MIN_RUNWAY_LENGTH = 2500  # feet
AIRPORT_TYPES = ['large_airport', 'medium_airport', 'small_airport']


def get_filtered_airports():
    """
    Download and filter airports to only those with paved runways >= 2500 ft
    Returns: (DataFrame of qualifying airports, DataFrame of all runways)
    """
    print("\nStep 1: Downloading airport data...")
    try:
        df_airports = pd.read_csv(AIRPORT_URL)
        print(f"  - Loaded {len(df_airports)} total airports")
        
        # Filter for US airports only
        us_airports = df_airports[df_airports['iso_country'] == 'US'].copy()
        print(f"  - US airports: {len(us_airports)}")
        
        # Filter by airport type
        us_airports = us_airports[us_airports['type'].isin(AIRPORT_TYPES)]
        print(f"  - After type filter: {len(us_airports)}")
        
    except Exception as e:
        print(f"ERROR downloading airport data: {e}")
        sys.exit(1)
    
    print("\nStep 2: Downloading runway data...")
    try:
        df_runways = pd.read_csv(RUNWAY_URL)
        print(f"  - Loaded {len(df_runways)} runways")
        
        # Filter for paved runways >= 2500 ft
        paved_runways = df_runways[
            (df_runways['surface'].isin(PAVED_SURFACES)) & 
            (df_runways['length_ft'] >= MIN_RUNWAY_LENGTH)
        ]
        print(f"  - Paved runways >= {MIN_RUNWAY_LENGTH} ft: {len(paved_runways)}")
        
        # Get unique airport IDs with qualifying runways
        qualifying_airport_ids = paved_runways['airport_ident'].unique()
        print(f"  - Airports with qualifying runways: {len(qualifying_airport_ids)}")
        
        # Filter airports to only those with qualifying runways
        filtered_airports = us_airports[us_airports['ident'].isin(qualifying_airport_ids)]
        print(f"  - After runway filter: {len(filtered_airports)}")
        
        # CRITICAL: Filter to ONLY 4-character airport identifiers
        # Valid identifiers:
        #   - ICAO: 4 chars starting with K (KDEN, KDFW, KPHX)
        #   - FAA 4-char: 4 alphanumeric (00CA, 03OR, 04CA)
        # Exclude:
        #   - 3-character FAA codes (DEN, DFW)
        #   - Internal OurAirports IDs (US-0149, etc.)
        #   - Any identifier containing hyphens or special characters
        #   - Anything not exactly 4 characters
        filtered_airports = filtered_airports[
            (filtered_airports['ident'].str.len() == 4) &
            (~filtered_airports['ident'].str.contains('-', na=False)) &
            (filtered_airports['ident'].str.match(r'^[A-Z0-9]{4}$'))
        ]
        print(f"  - After 4-char ICAO/FAA filter (excludes US-xxxx and 3-char codes): {len(filtered_airports)}")
        print(f"\nStep 3: Final filtered airports: {len(filtered_airports)}")
        
        return filtered_airports, df_runways
        
    except Exception as e:
        print(f"ERROR filtering by runway: {e}")
        sys.exit(1)


def get_longest_runway(airport_ident, runways_df):
    """Get the longest paved runway length for an airport"""
    airport_runways = runways_df[runways_df['airport_ident'] == airport_ident]
    if len(airport_runways) > 0:
        return int(airport_runways['length_ft'].max())
    return None


def repopulate_database(airports_df, runways_df):
    """
    Clear and repopulate the observations.airports table
    """
    try:
        print("\nStep 4: Connecting to database...")
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        
        # Backup warning
        print("\nWARNING: This will delete ALL existing data in observations.airports")
        response = input("Continue? (yes/no): ").strip().lower()
        if response != 'yes':
            print("Aborted.")
            sys.exit(0)
        
        # Clear existing data
        print("\nStep 5: Clearing existing airports table...")
        cur.execute("DELETE FROM observations.airports")
        deleted_count = cur.rowcount
        print(f"  - Deleted {deleted_count} existing records")
        
        # Insert filtered airports
        print("\nStep 6: Inserting filtered airports...")
        inserted = 0
        failed = 0
        
        # Filter runways for calculating longest_runway_ft
        paved_runways = runways_df[
            (runways_df['surface'].isin(PAVED_SURFACES)) & 
            (runways_df['length_ft'] >= MIN_RUNWAY_LENGTH)
        ]
        
        for idx, row in airports_df.iterrows():
            try:
                # Get longest paved runway for this airport
                longest_runway = get_longest_runway(row['ident'], paved_runways)
                
                # Convert elevation to integer, handle NaN
                elevation = None
                if pd.notna(row.get('elevation_ft')):
                    try:
                        elevation = int(row['elevation_ft'])
                    except (ValueError, TypeError):
                        elevation = None
                
                # Insert with actual schema columns
                cur.execute("""
                    INSERT INTO observations.airports (
                        station_id,
                        name,
                        location,
                        elevation_ft,
                        has_paved_runway,
                        longest_runway_ft
                    ) VALUES (
                        %s, %s, 
                        ST_SetSRID(ST_MakePoint(%s, %s), 4326),
                        %s, %s, %s
                    )
                """, (
                    row['ident'],  # No truncation - already filtered to 4 chars
                    row['name'],
                    row['longitude_deg'],
                    row['latitude_deg'],
                    elevation,
                    True,  # has_paved_runway (all filtered airports have paved runways)
                    longest_runway
                ))
                inserted += 1
                
                if inserted % 500 == 0:
                    print(f"  - Inserted {inserted} airports...")
                    
            except Exception as e:
                failed += 1
                if failed < 10:  # Only show first 10 errors
                    print(f"  - Warning: Failed to insert {row['ident']}: {e}")
        
        # Commit changes
        conn.commit()
        print(f"\nStep 7: Complete!")
        print(f"  - Successfully inserted: {inserted} airports")
        print(f"  - Failed insertions: {failed}")
        
        # Verify
        cur.execute("SELECT COUNT(*) FROM observations.airports")
        final_count = cur.fetchone()[0]
        print(f"  - Final table count: {final_count}")
        
        # Show sample
        print("\nSample of inserted airports:")
        cur.execute("""
            SELECT station_id, name, longest_runway_ft 
            FROM observations.airports 
            ORDER BY longest_runway_ft DESC 
            LIMIT 10
        """)
        for row in cur.fetchall():
            print(f"  {row[0]}: {row[1]} (longest runway: {row[2]} ft)")
        
        cur.close()
        conn.close()
        
    except psycopg2.Error as e:
        print(f"\nDATABASE ERROR: {e}")
        sys.exit(1)


def main():
    print("="*70)
    print("REPOPULATE observations.airports WITH RUNWAY FILTERING")
    print("="*70)
    print(f"\nCriteria:")
    print(f"  - Paved surfaces: {', '.join(PAVED_SURFACES)}")
    print(f"  - Minimum runway length: {MIN_RUNWAY_LENGTH} ft")
    print(f"  - Airport types: {', '.join(AIRPORT_TYPES)}")
    
    # Get filtered airports and runway data
    filtered_airports, runways_df = get_filtered_airports()
    
    # Show sample
    print("\nSample of airports to be inserted:")
    print(filtered_airports[['ident', 'name', 'type']].head(10))
    
    # Repopulate database
    repopulate_database(filtered_airports, runways_df)
    
    print("\n" + "="*70)
    print("DATABASE REPOPULATION COMPLETE")
    print("="*70)


if __name__ == "__main__":
    main()

