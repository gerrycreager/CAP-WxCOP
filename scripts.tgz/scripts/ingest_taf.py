#!/var/www/cap_winds_app/venv/bin/python3
"""
TAF Ingest Script
Monitors LDM TAF directories and ingests into PostGIS

Usage:
  # Process all TAFs from today
  python3 ingest_taf.py --today
  
  # Process specific date
  python3 ingest_taf.py --date 20260103
  
  # Monitor and process new files (for cron)
  python3 ingest_taf.py --recent 60
  
Cron:
  # Run every hour to process recent data
  0 * * * * /var/www/cap_winds_app/scripts/ingest_taf.py --recent 90 >> /var/log/taf_ingest.log 2>&1
"""

import sys
import os
import argparse
import logging
from datetime import datetime, timedelta
from pathlib import Path
import re
import json

# Add app directory to path
sys.path.insert(0, '/var/www/cap_winds_app')

try:
    from metar import Metar
    from metar.Datatypes import speed, distance, direction, temperature, pressure
    import psycopg2
    from db_config import get_connection
except ImportError as e:
    print(f"Missing dependency: {e}")
    print("Install with: pip install python-metar psycopg2-binary")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
log = logging.getLogger(__name__)

# LDM directory structure
LDM_TAF_ROOT = "/LDM/text/taf"

# Airport coordinates cache
AIRPORT_COORDS = {}


def get_airport_coordinates(station_id):
    """
    Get airport coordinates from cached data or OurAirports
    Returns (lat, lon) or None if not found
    """
    global AIRPORT_COORDS
    
    if station_id in AIRPORT_COORDS:
        return AIRPORT_COORDS[station_id]
    
    # Try to load from OurAirports CSV
    cache_file = "/var/www/cap_winds_app/.cache/airports.csv"
    
    if os.path.exists(cache_file):
        import csv
        with open(cache_file, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row['ident'] == station_id or row['gps_code'] == station_id:
                    lat = float(row['latitude_deg'])
                    lon = float(row['longitude_deg'])
                    AIRPORT_COORDS[station_id] = (lat, lon)
                    return (lat, lon)
    
    return None


def parse_taf_validity(taf_text):
    """
    Extract TAF validity period from text
    Returns (issue_time, valid_from, valid_to) as datetime objects
    
    TAF format: TAF KJFK 031725Z 0318/0424 ...
                         ^issue  ^valid from/to
    """
    try:
        # Find the validity line
        # Format: DDHHMMZ DDHH/DDHH
        match = re.search(r'(\d{2})(\d{2})(\d{2})Z\s+(\d{2})(\d{2})/(\d{2})(\d{2})', taf_text)
        if not match:
            return None, None, None
        
        issue_day = int(match.group(1))
        issue_hour = int(match.group(2))
        issue_min = int(match.group(3))
        
        valid_from_day = int(match.group(4))
        valid_from_hour = int(match.group(5))
        
        valid_to_day = int(match.group(6))
        valid_to_hour = int(match.group(7))
        
        # Construct datetime objects
        now = datetime.utcnow()
        
        # Issue time
        issue_time = datetime(now.year, now.month, issue_day, issue_hour, issue_min)
        if issue_time > now + timedelta(days=15):
            issue_time = issue_time.replace(month=issue_time.month - 1)
        
        # Valid from
        valid_from = datetime(now.year, now.month, valid_from_day, valid_from_hour, 0)
        if valid_from > now + timedelta(days=15):
            valid_from = valid_from.replace(month=valid_from.month - 1)
        
        # Valid to
        valid_to = datetime(now.year, now.month, valid_to_day, valid_to_hour, 0)
        if valid_to < valid_from:
            # Spans month boundary
            if valid_to.month == 12:
                valid_to = valid_to.replace(year=valid_to.year + 1, month=1)
            else:
                valid_to = valid_to.replace(month=valid_to.month + 1)
        
        return issue_time, valid_from, valid_to
        
    except Exception as e:
        log.error(f"Failed to parse TAF validity: {e}")
        return None, None, None


def parse_taf_periods(taf_text):
    """
    Parse TAF forecast periods
    Returns list of forecast period dicts
    
    Each period has: time_group, wind, visibility, weather, sky_conditions, etc.
    """
    periods = []
    
    try:
        # Split TAF into forecast groups (FM, TEMPO, PROB, BECMG)
        # Simplified parsing - store as structured data
        
        # Split on change groups
        parts = re.split(r'\s+(FM\d{6}|TEMPO|PROB\d{2}|BECMG)', taf_text)
        
        current_period = {'type': 'base'}
        
        for i, part in enumerate(parts):
            part = part.strip()
            
            if part in ['TEMPO', 'BECMG'] or part.startswith('PROB') or part.startswith('FM'):
                if current_period.get('conditions'):
                    periods.append(current_period)
                current_period = {'type': part, 'conditions': ''}
            else:
                if 'conditions' not in current_period:
                    current_period['conditions'] = ''
                current_period['conditions'] += ' ' + part
        
        if current_period.get('conditions'):
            periods.append(current_period)
        
    except Exception as e:
        log.error(f"Failed to parse TAF periods: {e}")
    
    return periods


def parse_taf(taf_text):
    """
    Parse TAF text and return database record
    Returns dict with parsed fields or None if parsing fails
    """
    try:
        # Extract station ID
        match = re.search(r'TAF\s+([A-Z]{4})', taf_text)
        if not match:
            log.warning(f"Could not extract station ID from TAF")
            return None
        
        station_id = match.group(1)
        
        # Get coordinates
        coords = get_airport_coordinates(station_id)
        if not coords:
            log.warning(f"No coordinates found for {station_id}")
            return None
        
        lat, lon = coords
        
        # Parse validity
        issue_time, valid_from, valid_to = parse_taf_validity(taf_text)
        if not issue_time:
            log.warning(f"Could not parse TAF validity for {station_id}")
            return None
        
        # Parse forecast periods
        periods = parse_taf_periods(taf_text)
        
        return {
            'station_id': station_id,
            'issue_time': issue_time,
            'valid_from': valid_from,
            'valid_to': valid_to,
            'raw_text': taf_text.strip(),
            'forecast_periods': json.dumps(periods),
            'lat': lat,
            'lon': lon
        }
        
    except Exception as e:
        log.error(f"Failed to parse TAF: {taf_text[:50]}... - {e}")
        return None


def insert_taf(conn, taf_data):
    """Insert parsed TAF into database"""
    try:
        cur = conn.cursor()
        
        cur.execute("""
            INSERT INTO observations.taf (
                station_id, issue_time, valid_from, valid_to,
                raw_text, forecast_periods, location
            ) VALUES (
                %(station_id)s, %(issue_time)s, %(valid_from)s, %(valid_to)s,
                %(raw_text)s, %(forecast_periods)s,
                ST_SetSRID(ST_MakePoint(%(lon)s, %(lat)s), 4326)
            )
            ON CONFLICT DO NOTHING
        """, taf_data)
        
        conn.commit()
        return True
        
    except Exception as e:
        log.error(f"Failed to insert TAF for {taf_data['station_id']}: {e}")
        conn.rollback()
        return False


def process_taf_file(filepath):
    """
    Process a single TAF file
    Returns (success_count, fail_count)
    """
    success = 0
    failed = 0
    
    try:
        with open(filepath, 'r', errors='ignore') as f:
            content = f.read()
        
        # Split into individual TAFs
        # TAFs start with "TAF" or "TAF AMD" or "TAF COR"
        tafs = re.split(r'\n(?=TAF\s)', content)
        
        conn = get_connection()
        
        for taf_text in tafs:
            taf_text = taf_text.strip()
            if len(taf_text) < 30:  # Skip too-short lines
                continue
            
            parsed = parse_taf(taf_text)
            if parsed:
                if insert_taf(conn, parsed):
                    success += 1
                else:
                    failed += 1
            else:
                failed += 1
        
        conn.close()
        
    except Exception as e:
        log.error(f"Failed to process file {filepath}: {e}")
        failed += 1
    
    return success, failed


def find_taf_files(date_str=None, minutes_recent=None):
    """
    Find TAF files to process
    
    Args:
        date_str: Date in YYYYMMDD format
        minutes_recent: Process files modified in last N minutes
    
    Returns:
        List of filepaths
    """
    files = []
    
    if date_str:
        # Process specific date
        year = date_str[:4]
        month = date_str[4:6]
        day = date_str[6:8]
        
        taf_dir = Path(LDM_TAF_ROOT) / year / month / day
        if taf_dir.exists():
            for f in taf_dir.glob('*'):
                if f.is_file():
                    files.append(str(f))
    
    elif minutes_recent:
        # Process recent files
        cutoff_time = datetime.now() - timedelta(minutes=minutes_recent)
        
        root = Path(LDM_TAF_ROOT)
        if not root.exists():
            return files
        
        # Check files recursively
        for f in root.rglob('*'):
            if f.is_file():
                mtime = datetime.fromtimestamp(f.stat().st_mtime)
                if mtime > cutoff_time:
                    files.append(str(f))
    
    return files


def main():
    parser = argparse.ArgumentParser(description='Ingest TAF data into PostGIS')
    
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--today', action='store_true', help='Process today\'s data')
    group.add_argument('--date', help='Process specific date (YYYYMMDD)')
    group.add_argument('--recent', type=int, metavar='MINUTES', 
                      help='Process files modified in last N minutes')
    
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Determine which files to process
    if args.today:
        date_str = datetime.utcnow().strftime('%Y%m%d')
        files = find_taf_files(date_str=date_str)
        log.info(f"Processing today's TAFs: {date_str}")
    elif args.date:
        files = find_taf_files(date_str=args.date)
        log.info(f"Processing TAFs for: {args.date}")
    else:  # args.recent
        files = find_taf_files(minutes_recent=args.recent)
        log.info(f"Processing TAFs from last {args.recent} minutes")
    
    if not files:
        log.info("No TAF files found to process")
        return
    
    log.info(f"Found {len(files)} file(s) to process")
    
    total_success = 0
    total_failed = 0
    
    for filepath in files:
        log.debug(f"Processing: {filepath}")
        success, failed = process_taf_file(filepath)
        total_success += success
        total_failed += failed
    
    log.info(f"Complete: {total_success} TAFs inserted, {total_failed} failed")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        log.info("\nInterrupted by user")
        sys.exit(1)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


