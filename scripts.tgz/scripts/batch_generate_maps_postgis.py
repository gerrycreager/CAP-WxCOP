#!/var/www/cap_winds_app/venv/bin/python3
"""
Fast PostGIS-Based Batch Map Generation
Queries model_wind_forecasts table instead of reading GRIB files
30x faster than GRIB-based generation!

Usage:
  ./batch_generate_maps_postgis.py

Cron (run at :20 past hour, after model ingest at :15):
  20 * * * * /var/www/cap_winds_app/scripts/batch_generate_maps_postgis.py >> /var/log/batch_maps.log 2>&1
"""
import sys
import os
import logging
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
import cartopy.crs as ccrs
import cartopy.feature as cfeature

sys.path.insert(0, '/var/www/cap_winds_app')
from db_config import get_connection

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
log = logging.getLogger(__name__)

OUTPUT_DIR = "/var/www/html/cap_winds"

# Region definitions (name, bbox: [west, south, east, north])
REGIONS = {
    'conus': {
        'name': 'Continental United States',
        'bbox': [-125, 24, -66, 50],
        'filename': 'conus.png'
    },
    'NCR': {
        'name': 'North Central Region',
        'bbox': [-104, 37, -80, 49],
        'filename': 'ncr.png'
    },
    'GLR': {
        'name': 'Great Lakes Region',
        'bbox': [-93, 37, -74, 49],
        'filename': 'glr.png'
    },
    'NER': {
        'name': 'Northeast Region',
        'bbox': [-81, 37, -66, 48],
        'filename': 'ner.png'
    },
    'SER': {
        'name': 'Southeast Region',
        'bbox': [-92, 24, -75, 40],
        'filename': 'ser.png'
    },
    'SWR': {
        'name': 'Southwest Region',
        'bbox': [-120, 31, -102, 42],
        'filename': 'swr.png'
    },
    'RMR': {
        'name': 'Rocky Mountain Region',
        'bbox': [-116, 36, -100, 49],
        'filename': 'rmr.png'
    },
    'PCR': {
        'name': 'Pacific Region',
        'bbox': [-125, 32, -114, 50],
        'filename': 'pcr.png'
    },
    'PCR-WEST': {
        'name': 'PCR-West Coast',
        'bbox': [-125, 32, -116, 49],
        'filename': 'pcr-west.png'
    },
    'PCR-AK': {
        'name': 'PCR-Alaska',
        'bbox': [-170, 51, -130, 72],
        'filename': 'pcr-ak.png'
    },
    'PCR-HI': {
        'name': 'PCR-Hawaii',
        'bbox': [-161, 18, -154, 23],
        'filename': 'pcr-hi.png'
    },
    'PCR-GUAM': {
        'name': 'PCR-Guam',
        'bbox': [144, 13, 146, 14],
        'filename': 'pcr-guam.png'
    },
    'SER-CARIB': {
        'name': 'SER-Caribbean',
        'bbox': [-68, 17, -64, 19],
        'filename': 'ser-carib.png'
    },
}


def get_latest_model_run():
    """Get the most recent model run time from database"""
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        cur.execute("""
            SELECT DISTINCT model_run 
            FROM observations.model_wind_forecasts 
            ORDER BY model_run DESC 
            LIMIT 1
        """)
        
        row = cur.fetchone()
        cur.close()
        conn.close()
        
        if row:
            return row[0]
        else:
            log.warning("No model runs found in database")
            return None
            
    except Exception as e:
        log.error(f"Error getting latest model run: {e}")
        return None


def get_wind_data_from_postgis(bbox, model_run, forecast_hour=0):
    """
    Query wind data from PostGIS for a region
    
    Args:
        bbox: [west, south, east, north]
        model_run: datetime of model run
        forecast_hour: forecast hour (0 for analysis/current)
    
    Returns:
        dict: {station_id: {'lat': lat, 'lon': lon, 'wind_dir': dir, 'wind_speed': speed, 'category': cat}}
    """
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        valid_time = model_run + timedelta(hours=forecast_hour)
        
        cur.execute("""
            SELECT 
                station_id,
                ST_Y(location) as latitude,
                ST_X(location) as longitude,
                wind_dir,
                wind_speed_kts,
                wind_gust_kts,
                wind_category
            FROM observations.model_wind_forecasts
            WHERE model_run = %s
              AND valid_time = %s
              AND ST_X(location) BETWEEN %s AND %s
              AND ST_Y(location) BETWEEN %s AND %s
              AND wind_speed_kts IS NOT NULL
        """, (model_run, valid_time, bbox[0], bbox[2], bbox[1], bbox[3]))
        
        winds = {}
        for row in cur.fetchall():
            station_id = row[0]
            winds[station_id] = {
                'lat': row[1],
                'lon': row[2],
                'wind_dir': row[3],
                'wind_speed': row[4],
                'wind_gust': row[5],
                'category': row[6]
            }
        
        cur.close()
        conn.close()
        
        log.info(f"  Retrieved {len(winds)} wind observations from PostGIS")
        return winds
        
    except Exception as e:
        log.error(f"Error querying wind data: {e}")
        return {}


def generate_map_from_postgis(region_code, region_info, model_run, forecast_hour=0):
    """
    Generate wind constraint map from PostGIS data
    
    Args:
        region_code: Region identifier
        region_info: Dict with name, bbox, filename
        model_run: datetime of model run
        forecast_hour: forecast hour to plot
    
    Returns:
        True on success, False on failure
    """
    try:
        log.info(f"Starting: {region_info['name']}")
        
        # Get wind data from PostGIS
        winds = get_wind_data_from_postgis(region_info['bbox'], model_run, forecast_hour)
        
        if not winds:
            log.warning(f"  No wind data for {region_info['name']}")
            return False
        
        # Create map
        bbox = region_info['bbox']
        fig = plt.figure(figsize=(14, 10), dpi=150)
        ax = plt.axes(projection=ccrs.PlateCarree())
        ax.set_extent(bbox, crs=ccrs.PlateCarree())
        
        # Add map features
        ax.add_feature(cfeature.LAND, facecolor='#f0f0f0', zorder=0)
        ax.add_feature(cfeature.OCEAN, facecolor='#d0e8ff', zorder=0)
        ax.add_feature(cfeature.COASTLINE, linewidth=0.5, zorder=1)
        ax.add_feature(cfeature.BORDERS, linewidth=0.5, linestyle=':', zorder=1)
        ax.add_feature(cfeature.STATES, linewidth=0.3, edgecolor='gray', zorder=1)
        
        # Add gridlines
        gl = ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
        gl.top_labels = False
        gl.right_labels = False
        
        # Plot wind categories as colored zones
        for station_id, data in winds.items():
            lat, lon = data['lat'], data['lon']
            category = data['category']
            
            # Color by wind category
            if category == 'EXTREME':
                color = '#8B0000'  # Dark red
                size = 100
            elif category == 'CAUTION':
                color = '#FFA500'  # Orange
                size = 80
            else:  # NORMAL
                color = '#00AA00'  # Green
                size = 60
            
            ax.scatter(lon, lat, s=size, c=color, alpha=0.6, 
                      edgecolors='black', linewidth=0.5, zorder=2,
                      transform=ccrs.PlateCarree())
        
        # Add wind barbs
        for station_id, data in winds.items():
            if data['wind_speed'] >= 5:  # Only show barbs for winds >= 5 kts
                lat, lon = data['lat'], data['lon']
                wind_dir = data['wind_dir']
                wind_speed = data['wind_speed']
                
                # Convert meteorological direction to u, v components
                wind_dir_rad = np.radians(270 - wind_dir)  # Meteorological to mathematical
                u = wind_speed * np.cos(wind_dir_rad)
                v = wind_speed * np.sin(wind_dir_rad)
                
                ax.barbs(lon, lat, u, v, length=5, barbcolor='black', 
                        flagcolor='black', linewidth=0.5, zorder=3,
                        transform=ccrs.PlateCarree())
        
        # Add title
        valid_time = model_run + timedelta(hours=forecast_hour)
        title = f"{region_info['name']}\n"
        title += f"Model Run: {model_run.strftime('%Y-%m-%d %H:00Z')} | "
        title += f"Valid: {valid_time.strftime('%Y-%m-%d %H:00Z')}"
        if forecast_hour > 0:
            title += f" (F+{forecast_hour:02d})"
        plt.title(title, fontsize=12, fontweight='bold', pad=10)
        
        # Add legend
        legend_elements = [
            plt.scatter([], [], s=60, c='#00AA00', edgecolors='black', label='Normal (<15 kt)'),
            plt.scatter([], [], s=80, c='#FFA500', edgecolors='black', label='Caution (15-24 kt)'),
            plt.scatter([], [], s=100, c='#8B0000', edgecolors='black', label='Extreme (≥25 kt)')
        ]
        ax.legend(handles=legend_elements, loc='lower right', fontsize=9, framealpha=0.9)
        
        # Add data source attribution
        plt.text(0.02, 0.02, 'Data: NOAA HRRR Model', 
                transform=ax.transAxes, fontsize=8, color='gray',
                verticalalignment='bottom')
        
        # Save map
        output_path = os.path.join(OUTPUT_DIR, region_info['filename'])
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        
        log.info(f"✓ Success: {region_info['name']} → {region_info['filename']}")
        return True
        
    except Exception as e:
        log.error(f"✗ Failed: {region_info['name']} - {str(e)}")
        return False


def cleanup_old_maps():
    """Remove maps older than 4 hours"""
    try:
        if not os.path.exists(OUTPUT_DIR):
            return
        
        cutoff_time = datetime.now() - timedelta(hours=4)
        removed = 0
        
        for filename in os.listdir(OUTPUT_DIR):
            if filename.endswith('.png'):
                filepath = os.path.join(OUTPUT_DIR, filename)
                mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
                
                if mtime < cutoff_time:
                    os.remove(filepath)
                    removed += 1
        
        if removed > 0:
            log.info(f"Cleaned up {removed} old map(s)")
            
    except Exception as e:
        log.warning(f"Cleanup error: {e}")


def main():
    log.info("=" * 70)
    log.info(f"Fast PostGIS Batch Map Generation - {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    log.info("=" * 70)
    
    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Get latest model run
    model_run = get_latest_model_run()
    if not model_run:
        log.error("No model data available in database")
        return 1
    
    log.info(f"Using model run: {model_run.strftime('%Y-%m-%d %H:00Z')}")
    
    # Generate maps for all regions
    success_count = 0
    fail_count = 0
    
    for region_code, region_info in REGIONS.items():
        if generate_map_from_postgis(region_code, region_info, model_run, forecast_hour=0):
            success_count += 1
        else:
            fail_count += 1
    
    # Cleanup old maps
    cleanup_old_maps()
    
    log.info("=" * 70)
    log.info(f"✓ Generation complete: {success_count} success, {fail_count} failed")
    log.info("=" * 70)
    
    return 0 if fail_count == 0 else 1


if __name__ == '__main__':
    sys.exit(main())

