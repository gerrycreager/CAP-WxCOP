AIRCRAFT INCIDENT WEATHER DATA ARCHIVE
Generated : 2026-02-17 19:03Z
Tool      : CAP METWatch Incident Archive Tool

INCIDENT PARAMETERS
  Time     : 2026-02-17 10:00Z
  Location : 38.8058, -104.7010
  Input    : KCOS

CONTENTS
  metars/
    all_metars.txt         All METAR/SPECI reports, sorted by station
    by_station/KXXX.txt    Individual station files
    (Window: 6hr ending at incident time, radius 100nm)
    (Stations: 27)

  tafs/
    all_tafs.txt           All TAFs valid at incident time
    (Lookback: 24hr, radius 100nm)
    (Stations: 0)

  radar/
    SITE_PRODUCT_dist/     One directory per site/product
      *.png                Georeferenced composite reflectivity images
    (Window: +/-1hr, radius 140nm)
    (Sites with data: 0)

  satellite/
    DOWNLOAD_INSTRUCTIONS.txt
    (Automated satellite download is Phase 2 - see instructions for manual retrieval)

  metadata.json            Machine-readable archive parameters

DATA SOURCES
  METARs/TAFs : Local PostgreSQL database (LDM ingest)
  Radar       : Local LDM archive (/LDM/radar/level3/)
  Satellite   : Manual download - see satellite/DOWNLOAD_INSTRUCTIONS.txt

CAP WEATHER TEAM TESTBED
