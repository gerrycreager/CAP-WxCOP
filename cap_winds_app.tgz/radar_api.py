"""
Radar API Blueprint for CAP Winds Weather Application
Provides REST API for radar data access and processing

Endpoints:
- GET /api/sites - List all NEXRAD sites
- GET /api/nearest/<airport> - Find nearest radar to airport
- GET /api/products/<site> - List available products for site
- GET /api/images/<site>/<product> - List available images
- GET /api/image/<site>/<product>/<timestamp> - Get specific image
"""

from flask import Blueprint, jsonify, request, send_file
import os
import json
import glob
from datetime import datetime, timedelta
from pathlib import Path
import logging

# Import our radar modules from scripts directory
try:
    from scripts.radar_sites import (
        NEXRAD_SITES, 
        find_nearest_radar, 
        get_site_info,
        get_all_sites,
        get_sites_by_region
    )
    from scripts.radar_processor import process_radar_image
except ImportError as e:
    logging.error(f"Error importing radar modules: {e}")
    NEXRAD_SITES = {}

# Create blueprint
radar_api = Blueprint('radar_api', __name__, url_prefix='/radar')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Base path for radar data
RADAR_BASE_PATH = '/LDM/radar/level3'


@radar_api.route('/api/sites')
def api_list_sites():
    """List all NEXRAD radar sites"""
    try:
        sites = get_all_sites()
        regions = get_sites_by_region()
        
        return jsonify({
            'count': len(sites),
            'sites': sites,
            'regions': {
                'alaska': len(regions['alaska']),
                'hawaii': len(regions['hawaii']),
                'guam': len(regions['guam']),
                'puerto_rico': len(regions['puerto_rico']),
                'conus': len(regions['conus'])
            }
        })
    except Exception as e:
        logger.error(f"Error listing sites: {e}")
        return jsonify({'error': str(e)}), 500


@radar_api.route('/api/nearest/<airport_id>')
def api_nearest_radar(airport_id):
    """
    Find nearest radar sites to an airport
    
    Args:
        airport_id: ICAO airport identifier (e.g., KMCO)
        
    Query params:
        max_sites: Maximum number of sites to return (default: 5)
    """
    try:
        airport_id = airport_id.upper()
        max_sites = request.args.get('max_sites', 5, type=int)
        
        # Get airport coordinates from database
        # For now, use example coordinates - you'll integrate with your airport database
        from db_config import get_connection
        
        conn = get_connection()
        cur = conn.cursor()
        
        # Try to find airport in METAR database
        cur.execute("""
            SELECT DISTINCT ON (station_id)
                station_id,
                ST_Y(location) as latitude,
                ST_X(location) as longitude
            FROM observations.metar
            WHERE station_id = %s
            ORDER BY station_id, observation_time DESC
            LIMIT 1
        """, (airport_id,))
        
        airport = cur.fetchone()
        cur.close()
        conn.close()
        
        if not airport:
            return jsonify({'error': f'Airport {airport_id} not found'}), 404
        
        airport_lat = airport[1]
        airport_lon = airport[2]
        
        # Find nearest radars
        nearest = find_nearest_radar(airport_lat, airport_lon, max_sites=max_sites)
        
        results = []
        for site_id, distance, site_info in nearest:
            results.append({
                'site_id': site_id,
                'distance_nm': round(distance, 1),
                'name': site_info['name'],
                'lat': site_info['lat'],
                'lon': site_info['lon'],
                'elevation_ft': site_info['elev']
            })
        
        return jsonify({
            'airport': airport_id,
            'airport_lat': airport_lat,
            'airport_lon': airport_lon,
            'nearest': results
        })
        
    except Exception as e:
        logger.error(f"Error finding nearest radar: {e}")
        return jsonify({'error': str(e)}), 500


@radar_api.route('/api/products/<site_id>')
def api_list_products(site_id):
    """
    List available radar products for a site
    
    Args:
        site_id: 4-letter radar site identifier
    """
    try:
        site_id = site_id.upper()
        
        # Check if site exists
        site_info = get_site_info(site_id)
        if not site_info:
            return jsonify({'error': f'Site {site_id} not found'}), 404
        
        # Check what products exist on disk
        site_path = os.path.join(RADAR_BASE_PATH, site_id)
        
        if not os.path.exists(site_path):
            return jsonify({
                'site_id': site_id,
                'products': []
            })
        
        products = []
        for item in os.listdir(site_path):
            product_path = os.path.join(site_path, item)
            if os.path.isdir(product_path):
                # Check if it has nids directory with data
                nids_path = os.path.join(product_path, 'nids')
                if os.path.exists(nids_path):
                    products.append(item)
        
        return jsonify({
            'site_id': site_id,
            'site_name': site_info['name'],
            'products': sorted(products)
        })
        
    except Exception as e:
        logger.error(f"Error listing products: {e}")
        return jsonify({'error': str(e)}), 500


@radar_api.route('/api/images/<site_id>/<product>')
def api_list_images(site_id, product):
    """
    List available radar images for a site/product
    
    Args:
        site_id: 4-letter radar site identifier
        product: Product code (e.g., N0Q)
        
    Query params:
        hours: Hours to look back (default: 2, max: 24)
        start: Start timestamp YYYYMMDD_HHMMSS (optional)
        end: End timestamp YYYYMMDD_HHMMSS (optional)
    """
    try:
        site_id = site_id.upper()
        product = product.upper()
        
        # Get parameters
        hours = min(int(request.args.get('hours', 2)), 24)
        start_ts = request.args.get('start')
        end_ts = request.args.get('end')
        
        # Check if site exists
        site_info = get_site_info(site_id)
        if not site_info:
            return jsonify({'error': f'Site {site_id} not found'}), 404
        
        # Find NIDS files
        nids_path = os.path.join(RADAR_BASE_PATH, site_id, product, 'nids')
        
        if not os.path.exists(nids_path):
            return jsonify({
                'site_id': site_id,
                'product': product,
                'count': 0,
                'images': []
            })
        
        # Get cutoff time
        if start_ts and end_ts:
            start_dt = datetime.strptime(start_ts, '%Y%m%d_%H%M%S')
            end_dt = datetime.strptime(end_ts, '%Y%m%d_%H%M%S')
        else:
            end_dt = datetime.utcnow()
            start_dt = end_dt - timedelta(hours=hours)
        
        # Find files
        images = []
        
        for date_dir in sorted(os.listdir(nids_path), reverse=True):
            date_path = os.path.join(nids_path, date_dir)
            if not os.path.isdir(date_path):
                continue
            
            for filename in sorted(os.listdir(date_path), reverse=True):
                if not filename.endswith('.nids'):
                    continue
                
                # Parse timestamp from filename: SITE_PRODUCT_HHMMSS.nids
                try:
                    parts = filename.replace('.nids', '').split('_')
                    time_part = parts[-1]  # HHMMSS
                    
                    # Combine date_dir (YYYYMMDD) and time_part (HHMMSS)
                    timestamp_str = f"{date_dir}_{time_part}"
                    file_dt = datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
                    
                    if file_dt < start_dt or file_dt > end_dt:
                        continue
                    
                    nids_file = os.path.join(date_path, filename)
                    
                    # Check if georeferenced PNG exists
                    geo_path = os.path.join(RADAR_BASE_PATH, site_id, product, 'geo', date_dir)
                    png_file = os.path.join(geo_path, filename.replace('.nids', '.png'))
                    json_file = os.path.join(geo_path, filename.replace('.nids', '.json'))
                    
                    cached = os.path.exists(png_file) and os.path.exists(json_file)
                    
                    # Get bounds if cached
                    bounds = None
                    if cached:
                        try:
                            with open(json_file, 'r') as f:
                                metadata = json.load(f)
                                bounds = metadata.get('bounds')
                        except:
                            pass
                    
                    images.append({
                        'timestamp': timestamp_str,
                        'time': file_dt.isoformat() + 'Z',
                        'nids_file': nids_file,
                        'geo_png': png_file if cached else None,
                        'cached': cached,
                        'bounds': bounds,
                        'url': f'/cap_winds_app/radar/api/image/{site_id}/{product}/{timestamp_str}'
                    })
                    
                except Exception as e:
                    logger.warning(f"Error parsing filename {filename}: {e}")
                    continue
        
        return jsonify({
            'site_id': site_id,
            'product': product,
            'count': len(images),
            'images': images
        })
        
    except Exception as e:
        logger.error(f"Error listing images: {e}")
        return jsonify({'error': str(e)}), 500


@radar_api.route('/api/image/<site_id>/<product>/<timestamp>')
def api_get_image(site_id, product, timestamp):
    """
    Get a specific georeferenced radar image
    
    Args:
        site_id: 4-letter radar site identifier
        product: Product code (e.g., N0Q)
        timestamp: Timestamp in format YYYYMMDD_HHMMSS
        
    Returns:
        PNG image with X-Radar-Bounds header containing bounds JSON
    """
    try:
        site_id = site_id.upper()
        product = product.upper()
        
        # Get site info
        site_info = get_site_info(site_id)
        if not site_info:
            return jsonify({'error': f'Site {site_id} not found'}), 404
        
        # Parse timestamp
        try:
            date_part = timestamp.split('_')[0]  # YYYYMMDD
            time_part = timestamp.split('_')[1]  # HHMMSS
        except:
            return jsonify({'error': 'Invalid timestamp format'}), 400
        
        # Build paths
        nids_file = os.path.join(RADAR_BASE_PATH, site_id, product, 'nids', 
                                date_part, f'{site_id}_{product}_{time_part}.nids')
        
        if not os.path.exists(nids_file):
            return jsonify({'error': 'NIDS file not found'}), 404
        
        # Check for cached PNG
        geo_dir = os.path.join(RADAR_BASE_PATH, site_id, product, 'geo', date_part)
        png_file = os.path.join(geo_dir, f'{site_id}_{product}_{time_part}.png')
        json_file = os.path.join(geo_dir, f'{site_id}_{product}_{time_part}.json')
        
        # Process if not cached
        if not os.path.exists(png_file) or not os.path.exists(json_file):
            logger.info(f"Processing radar image: {site_id} {product} {timestamp}")
            
            png_path, metadata = process_radar_image(
                site_id, product, nids_file,
                site_info['lat'], site_info['lon'],
                force=False
            )
            
            if not png_path:
                return jsonify({'error': 'Failed to process radar image'}), 500
        else:
            # Load metadata
            with open(json_file, 'r') as f:
                metadata = json.load(f)
        
        # Serve PNG with bounds in header
        response = send_file(png_file, mimetype='image/png')
        response.headers['X-Radar-Bounds'] = json.dumps(metadata['bounds'])
        response.headers['X-Radar-Product'] = product
        response.headers['X-Radar-Site'] = site_id
        response.headers['Cache-Control'] = 'public, max-age=3600'
        
        return response
        
    except Exception as e:
        logger.error(f"Error getting image: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@radar_api.route('/animation')
def radar_animation_page():
    """Serve the radar animation HTML page"""
    from flask import render_template
    return render_template('radar_animation.html')


# Health check endpoint
@radar_api.route('/api/health')
def api_health():
    """Check if radar system is operational"""
    try:
        # Check PyART availability
        import pyart
        pyart_version = pyart.__version__
        pyart_ok = True
    except:
        pyart_version = None
        pyart_ok = False
    
    # Check radar data directory
    data_dir_ok = os.path.exists(RADAR_BASE_PATH)
    
    # Count available sites
    available_sites = 0
    if data_dir_ok:
        try:
            available_sites = len([d for d in os.listdir(RADAR_BASE_PATH) 
                                 if os.path.isdir(os.path.join(RADAR_BASE_PATH, d))])
        except:
            pass
    
    status = 'healthy' if (pyart_ok and data_dir_ok) else 'degraded'
    
    return jsonify({
        'status': status,
        'pyart': {
            'available': pyart_ok,
            'version': pyart_version
        },
        'data_directory': {
            'path': RADAR_BASE_PATH,
            'exists': data_dir_ok,
            'available_sites': available_sites
        },
        'total_sites': len(NEXRAD_SITES)
    })


if __name__ == '__main__':
    # Test the blueprint
    from flask import Flask
    app = Flask(__name__)
    app.register_blueprint(radar_api)
    
    print("Radar API Blueprint registered")
    print("Available routes:")
    for rule in app.url_map.iter_rules():
        if rule.endpoint.startswith('radar_api'):
            print(f"  {rule.rule}")
    
    app.run(debug=True, port=5001)

