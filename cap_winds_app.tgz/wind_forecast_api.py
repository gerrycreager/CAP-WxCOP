#!/var/www/cap_winds_app/venv/bin/python3
"""
Wind Forecast API with Label Priority
Adds priority-based labeling for maps
"""

import sys
sys.path.insert(0, '/var/www/cap_winds_app')

from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
from db_config import get_connection
import logging
import re

wind_forecast_api = Blueprint('wind_forecast_api', __name__)
log = logging.getLogger(__name__)

# Civil Air Patrol Region bounding boxes
REGION_BOUNDS = {
    'CONUS': {'west': -125, 'south': 24, 'east': -66, 'north': 50},
    'NCR': {'west': -104, 'south': 37, 'east': -89, 'north': 49},
    'GLR': {'west': -93, 'south': 37, 'east': -80, 'north': 49},
    'MAR': {'west': -84, 'south': 32, 'east': -75, 'north': 40},
    'NER': {'west': -80, 'south': 39, 'east': -66, 'north': 48},
    'SER': {'west': -92, 'south': 24, 'east': -79, 'north': 37},
    'SER-PR': {'west': -68, 'south': 17, 'east': -65, 'north': 19},
    'SWR': {'west': -115, 'south': 25, 'east': -89, 'north': 37},
    'RMR': {'west': -117, 'south': 37, 'east': -102, 'north': 49},
    'PCR': {'west': -125, 'south': 32, 'east': -114, 'north': 49},
    'PCR-AK': {'west': -180, 'south': 51, 'east': -130, 'north': 72},
    'PCR-HI': {'west': -161, 'south': 18, 'east': -154, 'north': 23},
    'PCR-GUAM': {'west': 144, 'south': 13, 'east': 145, 'north': 14},
}


def get_label_priority(name, runway_ft, station_id):
    """
    Determine label priority for map display
    Returns: 1 (military), 2 (major), 3 (medium), 4 (small/no label)
    """
    if not name:
        return 4
    
    name_upper = name.upper()
    
    # Priority 1: Military installations
    military_keywords = [
        'AIR FORCE BASE', 'AFB', 'NAVAL', 'NAVY', 'MARINE', 'MCAS',
        'AIR STATION', 'NAS', 'AIR GUARD', 'ANG', 'MILITARY',
        'ARMY', 'COAST GUARD', 'SPACE FORCE'
    ]
    if any(keyword in name_upper for keyword in military_keywords):
        return 1
    
    # Priority 2: Major airports (long runways >= 10,000 ft)
    if runway_ft and runway_ft >= 10000:
        return 2
    
    # Priority 2: International airports (by name)
    if 'INTERNATIONAL' in name_upper:
        return 2
    
    # Priority 3: Medium airports (6,000 - 10,000 ft runways)
    if runway_ft and runway_ft >= 6000:
        return 3
    
    # Priority 4: Small airports (don't label)
    return 4


def get_wind_forecasts_in_bounds(west, south, east, north, limit=5000):
    """
    Query model_wind_forecasts with JOIN to airports table
    Includes label priority for smart map labeling
    """
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        # Get latest model run
        cur.execute("""
            SELECT DISTINCT model_run 
            FROM observations.model_wind_forecasts 
            ORDER BY model_run DESC 
            LIMIT 1
        """)
        
        result = cur.fetchone()
        if not result:
            cur.close()
            conn.close()
            log.warning("No model runs found in database")
            return []
        
        latest_run = result[0]
        log.info(f"Using model run: {latest_run}")
        
        # Query WITH JOIN to airports table
        query = """
        SELECT 
            mwf.station_id,
            ST_X(mwf.location::geometry) as lon,
            ST_Y(mwf.location::geometry) as lat,
            MAX(mwf.wind_speed_kts) as max_wind_kts,
            MAX(mwf.wind_gust_kts) as max_gust_kts,
            MIN(mwf.wind_speed_kts) as min_wind_kts,
            mwf.model_name,
            mwf.wind_category,
            a.name as airport_name,
            a.longest_runway_ft
        FROM observations.model_wind_forecasts mwf
        INNER JOIN observations.airports a ON mwf.station_id = a.station_id
        WHERE mwf.model_run = %s
            AND ST_X(mwf.location::geometry) BETWEEN %s AND %s
            AND ST_Y(mwf.location::geometry) BETWEEN %s AND %s
            AND mwf.forecast_hour <= 12
        GROUP BY mwf.station_id, mwf.location, mwf.model_name, mwf.wind_category, a.name, a.longest_runway_ft
        ORDER BY MAX(mwf.wind_speed_kts) DESC
        LIMIT %s
        """
        
        cur.execute(query, (latest_run, west, east, south, north, limit))
        
        airports = []
        for row in cur.fetchall():
            station_id = row[0]
            name = row[8] or station_id
            runway_ft = int(row[9]) if row[9] else None
            
            # Determine label priority
            label_priority = get_label_priority(name, runway_ft, station_id)
            
            airports.append({
                'station_id': station_id,
                'lon': float(row[1]) if row[1] else 0,
                'lat': float(row[2]) if row[2] else 0,
                'max_wind_kts': int(row[3]) if row[3] else 0,
                'max_gust_kts': int(row[4]) if row[4] else None,
                'min_wind_kts': int(row[5]) if row[5] else 0,
                'max_wind_time': None,
                'max_gust_time': None,
                'model': row[6] or 'HRRR',
                'category': row[7] or 'NORMAL',
                'name': name,
                'longest_runway_ft': runway_ft,
                'label_priority': label_priority,  # NEW: For smart labeling
                'type': 'airport'
            })
        
        cur.close()
        conn.close()
        
        log.info(f"Query returned {len(airports)} airports in bounds [{west},{south},{east},{north}]")
        return airports
        
    except Exception as e:
        log.error(f"Error querying wind forecasts: {e}", exc_info=True)
        try:
            cur.close()
            conn.close()
        except:
            pass
        return []


@wind_forecast_api.route('/region/<region_code>')
def get_region_forecasts(region_code):
    """Get wind forecasts for a CAP region"""
    region_code = region_code.upper()
    
    if region_code not in REGION_BOUNDS:
        return jsonify({'error': 'Invalid region code'}), 400
    
    bounds = REGION_BOUNDS[region_code]
    airports = get_wind_forecasts_in_bounds(
        bounds['west'], bounds['south'], 
        bounds['east'], bounds['north']
    )
    
    return jsonify({
        'region': region_code,
        'bounds': bounds,
        'count': len(airports),
        'airports': airports,
        'timestamp': datetime.utcnow().isoformat()
    })


@wind_forecast_api.route('/state/<state_code>')
def get_state_forecasts(state_code):
    """Get wind forecasts for a US state"""
    state_code = state_code.upper()
    
    # State bounding boxes (simplified - you may want more precise bounds)
    state_bounds = {
        'AZ': {'west': -115, 'south': 31, 'east': -109, 'north': 37},
        'CO': {'west': -109, 'south': 37, 'east': -102, 'north': 41},
        'NV': {'west': -120, 'south': 35, 'east': -114, 'north': 42},
        'NM': {'west': -109, 'south': 31, 'east': -103, 'north': 37},
        'UT': {'west': -114, 'south': 37, 'east': -109, 'north': 42},
        'WY': {'west': -111, 'south': 41, 'east': -104, 'north': 45},
        # Add more states as needed
    }
    
    if state_code not in state_bounds:
        return jsonify({'error': 'State not supported or bounds not defined'}), 400
    
    bounds = state_bounds[state_code]
    airports = get_wind_forecasts_in_bounds(
        bounds['west'], bounds['south'], 
        bounds['east'], bounds['north']
    )
    
    return jsonify({
        'state': state_code,
        'bounds': bounds,
        'count': len(airports),
        'airports': airports,
        'timestamp': datetime.utcnow().isoformat()
    })


@wind_forecast_api.route('/conus')
def get_conus_forecasts():
    """Get wind forecasts for entire CONUS"""
    bounds = REGION_BOUNDS['CONUS']
    airports = get_wind_forecasts_in_bounds(
        bounds['west'], bounds['south'], 
        bounds['east'], bounds['north']
    )
    
    return jsonify({
        'region': 'CONUS',
        'bounds': bounds,
        'count': len(airports),
        'airports': airports,
        'timestamp': datetime.utcnow().isoformat()
    })


@wind_forecast_api.route('/bounds')
def get_custom_bounds_forecasts():
    """Get wind forecasts for custom bounding box"""
    try:
        west = float(request.args.get('west'))
        south = float(request.args.get('south'))
        east = float(request.args.get('east'))
        north = float(request.args.get('north'))
    except (TypeError, ValueError):
        return jsonify({'error': 'Invalid bounds parameters'}), 400
    
    airports = get_wind_forecasts_in_bounds(west, south, east, north)
    
    return jsonify({
        'bounds': {'west': west, 'south': south, 'east': east, 'north': north},
        'count': len(airports),
        'airports': airports,
        'timestamp': datetime.utcnow().isoformat()
    })


@wind_forecast_api.route('/status')
def get_status():
    """Get API status"""
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        # Get latest model run
        cur.execute("""
            SELECT model_run, COUNT(*) as forecast_count
            FROM observations.model_wind_forecasts
            GROUP BY model_run
            ORDER BY model_run DESC
            LIMIT 1
        """)
        
        result = cur.fetchone()
        if result:
            latest_run, forecast_count = result
            status = 'operational'
        else:
            latest_run = None
            forecast_count = 0
            status = 'no_data'
        
        cur.close()
        conn.close()
        
        return jsonify({
            'status': status,
            'latest_model_run': latest_run.isoformat() if latest_run else None,
            'forecast_count': forecast_count,
            'timestamp': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500

