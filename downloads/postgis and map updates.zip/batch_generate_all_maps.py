#!/var/www/cap_winds_app/venv/bin/python3
"""
COMPREHENSIVE Batch Map Generation - ALL CONUS, REGIONS, AND STATES
Generates aviation wind maps for maximum coverage

This script generates:
- CONUS (1 map)
- All CAP regions (13 maps)
- All 50 US states (50 maps)
- Total: 64 maps per run

Runtime: ~60-90 minutes for complete run
Recommended: Run every 3 hours (not hourly due to runtime)

Usage:
  ./batch_generate_all_maps.py --all              # Generate everything
  ./batch_generate_all_maps.py --regions-only     # Just regions (fast, 20 min)
  ./batch_generate_all_maps.py --states-only      # Just states (slow, 60 min)

Cron (every 3 hours):
  5 */3 * * * /var/www/cap_winds_app/batch_generate_all_maps.py --all >> /var/log/batch_maps_all.log 2>&1
"""

import sys
import os
import argparse
import logging
from datetime import datetime

# Add app directory to path
sys.path.insert(0, '/var/www/cap_winds_app')

try:
    from states_service import StatesService
except ImportError as e:
    print(f"Error importing StatesService: {e}")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
log = logging.getLogger(__name__)

# Output directory
OUTPUT_DIR = "/var/www/html/cap_winds"

# CONUS map
CONUS_MAP = ("CONUS", "Continental United States", "conus.png")

# Region configurations (13 total)
REGIONS = [
    ("NCR", "North Central Region", "ncr.png"),
    ("GLR", "Great Lakes Region", "glr.png"),
    ("NER", "Northeast Region", "ner.png"),
    ("PCR", "Pacific Region", "pcr.png"),
    ("PCR-WEST", "PCR-West Coast", "pcr-west.png"),
    ("PCR-AK", "PCR-Alaska", "pcr-ak.png"),
    ("PCR-HI", "PCR-Hawaii", "pcr-hi.png"),
    ("PCR-GUAM", "PCR-Guam", "pcr-guam.png"),
    ("RMR", "Rocky Mountain Region", "rmr.png"),
    ("SER", "Southeast Region", "ser.png"),
    ("SER-CARIB", "SER-Caribbean", "ser-carib.png"),
    ("SWR", "Southwest Region", "swr.png"),
]

# All 50 US states
STATES = [
    ("AL", "Alabama", "al.png"),
    ("AK", "Alaska", "ak.png"),
    ("AZ", "Arizona", "az.png"),
    ("AR", "Arkansas", "ar.png"),
    ("CA", "California", "ca.png"),
    ("CO", "Colorado", "co.png"),
    ("CT", "Connecticut", "ct.png"),
    ("DE", "Delaware", "de.png"),
    ("FL", "Florida", "fl.png"),
    ("GA", "Georgia", "ga.png"),
    ("HI", "Hawaii", "hi.png"),
    ("ID", "Idaho", "id.png"),
    ("IL", "Illinois", "il.png"),
    ("IN", "Indiana", "in.png"),
    ("IA", "Iowa", "ia.png"),
    ("KS", "Kansas", "ks.png"),
    ("KY", "Kentucky", "ky.png"),
    ("LA", "Louisiana", "la.png"),
    ("ME", "Maine", "me.png"),
    ("MD", "Maryland", "md.png"),
    ("MA", "Massachusetts", "ma.png"),
    ("MI", "Michigan", "mi.png"),
    ("MN", "Minnesota", "mn.png"),
    ("MS", "Mississippi", "ms.png"),
    ("MO", "Missouri", "mo.png"),
    ("MT", "Montana", "mt.png"),
    ("NE", "Nebraska", "ne.png"),
    ("NV", "Nevada", "nv.png"),
    ("NH", "New Hampshire", "nh.png"),
    ("NJ", "New Jersey", "nj.png"),
    ("NM", "New Mexico", "nm.png"),
    ("NY", "New York", "ny.png"),
    ("NC", "North Carolina", "nc.png"),
    ("ND", "North Dakota", "nd.png"),
    ("OH", "Ohio", "oh.png"),
    ("OK", "Oklahoma", "ok.png"),
    ("OR", "Oregon", "or.png"),
    ("PA", "Pennsylvania", "pa.png"),
    ("RI", "Rhode Island", "ri.png"),
    ("SC", "South Carolina", "sc.png"),
    ("SD", "South Dakota", "sd.png"),
    ("TN", "Tennessee", "tn.png"),
    ("TX", "Texas", "tx.png"),
    ("UT", "Utah", "ut.png"),
    ("VT", "Vermont", "vt.png"),
    ("VA", "Virginia", "va.png"),
    ("WA", "Washington", "wa.png"),
    ("WV", "West Virginia", "wv.png"),
    ("WI", "Wisconsin", "wi.png"),
    ("WY", "Wyoming", "wy.png"),
]


def generate_map(service, code, display_name, output_filename):
    """
    Generate map for a single location
    Returns True on success, False on failure
    """
    try:
        log.info(f"Starting: {display_name} ({code})")
        
        # Generate the analysis
        result = service.generate_analysis(
            location_or_coords=code,
            radius_nm=None,
            output_path=OUTPUT_DIR,
            model="auto",
            output_format="png",
            include_shapefiles=True
        )
        
        if result and 'maps' in result and result['maps']:
            # Get the generated map path
            generated_map = result['maps'][0]
            
            # Rename to static filename (overwrite previous)
            static_path = os.path.join(OUTPUT_DIR, output_filename)
            if os.path.exists(generated_map) and generated_map != static_path:
                os.rename(generated_map, static_path)
            
            log.info(f"✓ Success: {display_name} → {output_filename}")
            return True
        else:
            log.error(f"✗ Failed: {display_name} - No maps generated")
            return False
            
    except Exception as e:
        log.error(f"✗ Failed: {display_name} - {str(e)}")
        return False


def cleanup_old_timestamped_maps():
    """Clean up old timestamped maps from previous versions"""
    if not os.path.exists(OUTPUT_DIR):
        return
    
    try:
        import re
        timestamped_pattern = re.compile(r'.*_\d{6}Z[A-Z]{3}\d{2}\.png$')
        
        removed_count = 0
        for filename in os.listdir(OUTPUT_DIR):
            if timestamped_pattern.match(filename):
                filepath = os.path.join(OUTPUT_DIR, filename)
                try:
                    os.remove(filepath)
                    removed_count += 1
                except Exception as e:
                    log.debug(f"Could not remove {filename}: {e}")
        
        if removed_count > 0:
            log.info(f"Cleaned up {removed_count} old timestamped maps")
            
    except Exception as e:
        log.debug(f"Cleanup error: {e}")


def main():
    """Main execution"""
    parser = argparse.ArgumentParser(
        description='Generate comprehensive set of aviation wind maps'
    )
    parser.add_argument('--all', action='store_true',
                       help='Generate CONUS, all regions, and all states (default)')
    parser.add_argument('--regions-only', action='store_true',
                       help='Generate only CONUS and regions (faster, ~20 min)')
    parser.add_argument('--states-only', action='store_true',
                       help='Generate only states (slower, ~60 min)')
    
    args = parser.parse_args()
    
    # Default to --all if no options specified
    if not (args.all or args.regions_only or args.states_only):
        args.all = True
    
    log.info("=" * 70)
    log.info(f"Comprehensive Batch Map Generation Started: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    
    if args.all:
        log.info("Mode: COMPLETE (CONUS + Regions + States)")
    elif args.regions_only:
        log.info("Mode: REGIONS ONLY (CONUS + Regions)")
    elif args.states_only:
        log.info("Mode: STATES ONLY")
    
    log.info("=" * 70)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Initialize service
    try:
        service = StatesService()
    except Exception as e:
        log.error(f"Failed to initialize StatesService: {e}")
        sys.exit(1)
    
    # Track results
    succeeded = []
    failed = []
    start_time = datetime.now()
    
    # Generate maps based on mode
    maps_to_generate = []
    
    if args.all or args.regions_only:
        # Add CONUS
        maps_to_generate.append(CONUS_MAP)
        # Add regions
        maps_to_generate.extend(REGIONS)
    
    if args.all or args.states_only:
        # Add states
        maps_to_generate.extend(STATES)
    
    log.info(f"Generating {len(maps_to_generate)} maps...")
    log.info("")
    
    # Generate each map
    for i, (code, display_name, output_filename) in enumerate(maps_to_generate, 1):
        log.info(f"[{i}/{len(maps_to_generate)}] Processing: {display_name}")
        
        success = generate_map(service, code, display_name, output_filename)
        
        if success:
            succeeded.append(display_name)
        else:
            failed.append(display_name)
        
        # Show progress
        elapsed = (datetime.now() - start_time).total_seconds()
        avg_time = elapsed / i
        remaining = avg_time * (len(maps_to_generate) - i)
        
        log.info(f"Progress: {i}/{len(maps_to_generate)} ({i*100//len(maps_to_generate)}%) | "
                f"Elapsed: {elapsed/60:.1f}min | ETA: {remaining/60:.1f}min")
        log.info("")
    
    # Clean up old timestamped maps
    cleanup_old_timestamped_maps()
    
    # Summary
    elapsed_total = (datetime.now() - start_time).total_seconds()
    
    log.info("=" * 70)
    log.info(f"Batch Generation Complete!")
    log.info(f"  Succeeded: {len(succeeded)}")
    log.info(f"  Failed: {len(failed)}")
    log.info(f"  Total time: {elapsed_total/60:.1f} minutes")
    log.info(f"  Average per map: {elapsed_total/len(maps_to_generate):.1f} seconds")
    
    if failed:
        log.info(f"Failed maps: {', '.join(failed[:10])}")
        if len(failed) > 10:
            log.info(f"  ... and {len(failed)-10} more")
    
    log.info("=" * 70)
    
    # Exit with appropriate code
    sys.exit(0 if len(failed) == 0 else 1)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        log.info("\nInterrupted by user")
        sys.exit(1)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


"""
=============================================================================
DEPLOYMENT AND USAGE
=============================================================================

1. Deploy script:
   cp batch_generate_all_maps.py /var/www/cap_winds_app/
   chmod +x /var/www/cap_winds_app/batch_generate_all_maps.py
   chown www-data:www-data /var/www/cap_winds_app/batch_generate_all_maps.py

2. Test runs:
   
   # Test with regions only (faster, ~20 min)
   sudo -u www-data /var/www/cap_winds_app/batch_generate_all_maps.py --regions-only
   
   # Full run (slow, ~90 min)
   sudo -u www-data /var/www/cap_winds_app/batch_generate_all_maps.py --all

3. Set up cron jobs:
   
   sudo crontab -u www-data -e
   
   # Option A: Regions every hour, states every 3 hours
   5 * * * * /var/www/cap_winds_app/batch_generate_all_maps.py --regions-only >> /var/log/batch_maps_regions.log 2>&1
   5 */3 * * * /var/www/cap_winds_app/batch_generate_all_maps.py --states-only >> /var/log/batch_maps_states.log 2>&1
   
   # Option B: Everything every 3 hours (simpler)
   5 */3 * * * /var/www/cap_winds_app/batch_generate_all_maps.py --all >> /var/log/batch_maps_all.log 2>&1

4. Create log files:
   sudo touch /var/log/batch_maps_all.log
   sudo chown www-data:www-data /var/log/batch_maps_all.log

5. Monitor progress:
   tail -f /var/log/batch_maps_all.log

=============================================================================
EXPECTED OUTPUT
=============================================================================

After complete run (--all):
  /var/www/html/cap_winds/conus.png        (CONUS)
  /var/www/html/cap_winds/ncr.png          (Regions x 12)
  /var/www/html/cap_winds/glr.png
  ...
  /var/www/html/cap_winds/tx.png           (States x 50)
  /var/www/html/cap_winds/ca.png
  ...
  
Total: 64 maps (1 CONUS + 13 regions + 50 states)

=============================================================================
PERFORMANCE NOTES
=============================================================================

Typical runtimes:
  CONUS: 4-5 minutes
  Each region: 1-3 minutes  
  Each state: 1-2 minutes
  
  --regions-only: ~20 minutes (1 + 13 maps)
  --states-only: ~60 minutes (50 maps)
  --all: ~90 minutes (64 maps)

Recommended schedule:
  Regions every hour (current, fast)
  States every 3 hours (comprehensive)
  
Disk usage:
  64 maps × ~1 MB average = ~64 MB total

=============================================================================
"""
